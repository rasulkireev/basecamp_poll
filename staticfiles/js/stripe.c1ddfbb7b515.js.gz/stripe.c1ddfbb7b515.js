
// Set your publishable key: remember to change this to your live publishable key in production
// See your keys here: https://dashboard.stripe.com/account/apikeys
var stripe = Stripe('pk_test_51H47wOHQF19ZH0rLZhU6pmpCpWNhHZ56gNuOe6zx8VXqxFuYoAf9G0mzNxMThfmuEquFRqGslUaIsNawposHtb8c00cKJ7ZPT8');
var elements = stripe.elements();

console.log("Hello")